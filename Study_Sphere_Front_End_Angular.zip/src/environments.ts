//export const Local_Ip='192.168.0.142'//hostel
export const Local_Ip='192.168.110.132'//hostel ali 7

//export const Local_Ip='192.168.169.201'//Mobile Hotspot

//export const Local_Ip='192.168.110.132'//hostel Ali 6 5g
// export const Local_Ip='127.0.0.1'//offline
//export const Local_Ip='172.18.78.26'// prc student 
//export const Local_Ip='192.168.110.132'//Local host

