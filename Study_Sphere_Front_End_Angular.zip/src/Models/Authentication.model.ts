export interface formdata{
    username:string;
    email:string,
    password:string,
    password_retry:string,
    save_me:boolean
  
  }
