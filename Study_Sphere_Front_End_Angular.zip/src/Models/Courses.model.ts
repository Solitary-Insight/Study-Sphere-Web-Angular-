export interface Course{
    course_name:string,
    course_id:number,
}