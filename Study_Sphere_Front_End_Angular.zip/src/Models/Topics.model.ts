export interface Topic{
    topic_name:string,
    course_id:number
    topic_id:number
}