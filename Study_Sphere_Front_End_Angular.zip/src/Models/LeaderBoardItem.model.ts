export interface LeaderBoardItem {
    student_id: number;
    username: string;
    email: string;
    total_quizzes_attempted: number;
    total_questions_attempted: number;
    total_correct_answers: number;
  }