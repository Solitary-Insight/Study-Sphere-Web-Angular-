export interface Student{
    username:string ;
    password:string ;
    student_id:number;
    email:string ;
    role:string ;
    
}

