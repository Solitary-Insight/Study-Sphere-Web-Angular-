import { Course } from "../Models/Courses.model";

export const courses: Course[] = [
    { course_name: 'Physics', course_id: 101 },
    { course_name: 'Chemistry', course_id: 102 },
    { course_name: 'Math', course_id: 103 },
    { course_name: 'Biology', course_id: 104 },
    { course_name: 'English', course_id: 105 },
   
  ];